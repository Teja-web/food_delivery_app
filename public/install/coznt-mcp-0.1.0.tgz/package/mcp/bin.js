#!/usr/bin/env node
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { ListToolsRequestSchema, CallToolRequestSchema, ListResourcesRequestSchema, ReadResourceRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import { randomUUID } from 'crypto';
import { promises, readFileSync } from 'fs';
import * as path from 'path';
import { join } from 'path';
import { execSync } from 'child_process';
import * as os from 'os';

// src/lib/agent-context/version.ts
var MCP_VERSION = "0.1.0";

// src/mcp/client.ts
var CozntApiError = class extends Error {
  constructor(message, status, details) {
    super(message);
    this.status = status;
    this.details = details;
    this.name = "CozntApiError";
  }
  status;
  details;
};
function readConfig() {
  const baseUrl = (process.env.COZNT_URL ?? "http://localhost:3029").replace(/\/$/, "");
  const apiKey = process.env.COZNT_API_KEY;
  if (!apiKey) {
    throw new Error("COZNT_API_KEY is required (project-pinned API key minted at /api-keys).");
  }
  return { baseUrl, apiKey };
}
var CozntClient = class {
  constructor(cfg) {
    this.cfg = cfg;
  }
  cfg;
  async request(method, path3, body) {
    const headers = {
      Authorization: `Bearer ${this.cfg.apiKey}`,
      "Content-Type": "application/json"
    };
    const repoUrl = process.env.COZNT_REPO_URL;
    if (repoUrl) headers["X-Coznt-Repo-Url"] = repoUrl;
    const res = await fetch(`${this.cfg.baseUrl}${path3}`, {
      method,
      headers,
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
    const text = await res.text();
    let parsed = null;
    if (text.length > 0) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) {
      const errBody = parsed;
      throw new CozntApiError(
        errBody?.error ?? `${method} ${path3} failed (${res.status})`,
        res.status,
        errBody?.details
      );
    }
    return parsed;
  }
  get(path3) {
    return this.request("GET", path3);
  }
  post(path3, body) {
    return this.request("POST", path3, body);
  }
  patch(path3, body) {
    return this.request("PATCH", path3, body);
  }
};
var current = null;
function startLocalSession(intent) {
  current = {
    localId: randomUUID(),
    serverId: null,
    startedAt: /* @__PURE__ */ new Date(),
    endedAt: null,
    intent,
    toolCalls: 0,
    project: null,
    drafts: []
  };
  return current;
}
function setSessionProject(project) {
  if (!current) startLocalSession(null);
  current.project = project;
}
function getSessionProject() {
  return current?.project ?? null;
}
function ensureSession() {
  if (!current) startLocalSession(null);
  return current;
}
function listDrafts() {
  return current?.drafts ?? [];
}
function addDraft(input) {
  const s = ensureSession();
  const now = /* @__PURE__ */ new Date();
  const draft = {
    id: randomUUID(),
    createdAt: now,
    updatedAt: now,
    ...input
  };
  s.drafts.push(draft);
  return draft;
}
function updateDraft(id, patch) {
  if (!current) return null;
  const idx = current.drafts.findIndex((d) => d.id === id);
  if (idx === -1) return null;
  current.drafts[idx] = { ...current.drafts[idx], ...patch, updatedAt: /* @__PURE__ */ new Date() };
  return current.drafts[idx];
}
function deleteDraft(id) {
  if (!current) return false;
  const idx = current.drafts.findIndex((d) => d.id === id);
  if (idx === -1) return false;
  current.drafts.splice(idx, 1);
  return true;
}
function clearDrafts() {
  if (current) current.drafts = [];
}
function attachServerId(serverId) {
  if (current) current.serverId = serverId;
}
function endLocalSession() {
  if (!current) return null;
  current.endedAt = /* @__PURE__ */ new Date();
  const ended = current;
  current = null;
  return ended;
}
function getCurrentSession() {
  return current;
}
function bumpToolCall() {
  if (current) current.toolCalls += 1;
}

// src/mcp/resources/conventions.ts
async function readConventions(client) {
  const data = await client.get("/api/v1/rules?limit=200");
  return {
    contents: [
      {
        uri: "coznt://conventions",
        mimeType: "application/json",
        text: JSON.stringify(
          {
            schema: "https://coznt.io/schemas/conventions.v1",
            rules: data.items.map((r) => ({
              slug: r.slug,
              title: r.title,
              severity: r.severity,
              phase: r.phase,
              tags: r.tags ?? [],
              body: r.body
            }))
          },
          null,
          2
        )
      }
    ]
  };
}

// src/mcp/resources/history.ts
async function readHistory(client) {
  let data = { rows: [] };
  try {
    data = await client.get("/api/v1/mcp/history?range=7d&limit=50");
  } catch {
    data = { rows: [] };
  }
  return {
    contents: [
      {
        uri: "coznt://history",
        mimeType: "application/json",
        text: JSON.stringify(
          {
            schema: "https://coznt.io/schemas/history.v1",
            rangeDays: 7,
            events: data.rows.map((r) => ({
              at: r.occurredAtIso,
              actor: { type: r.actorType, name: r.actorName },
              action: r.action,
              entityType: r.entityType,
              summary: r.summary,
              signature: r.signature ?? null
            }))
          },
          null,
          2
        )
      }
    ]
  };
}

// src/mcp/resources/my-tasks.ts
async function readMyTasks(client) {
  const [items, plans] = await Promise.all([
    client.get("/api/v1/work-items?limit=20"),
    client.get("/api/v1/plans?limit=20")
  ]);
  return {
    contents: [
      {
        uri: "coznt://my-tasks",
        mimeType: "application/json",
        text: JSON.stringify(
          {
            schema: "https://coznt.io/schemas/my-tasks.v1",
            workItems: items.items.map((i) => ({
              id: i.id,
              title: i.title,
              status: i.status,
              priority: i.priority,
              assigneeName: i.assigneeName,
              externalRef: i.externalRef
            })),
            plans: plans.items.map((p) => ({
              id: p.id,
              title: p.title,
              kind: p.kind,
              status: p.status,
              priority: p.priority,
              assigneeName: p.assigneeName
            }))
          },
          null,
          2
        )
      }
    ]
  };
}
var checkStandardsInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  plan: z.object({
    kind: z.enum([
      "epic",
      "feature",
      "story",
      "adr",
      "test_plan",
      "release_plan",
      "incident"
    ]),
    title: z.string().min(1),
    summary: z.string().optional(),
    body: z.string().optional()
  }).optional().describe(
    "Proposed plan content. Runs keyword-presence rules against title+summary+body."
  ),
  action: z.object({
    appliesTo: z.enum(["skill", "task", "deployment"]),
    command: z.string().optional(),
    paths: z.array(z.string()).optional(),
    fileCount: z.number().int().nonnegative().optional(),
    hasTests: z.boolean().optional()
  }).optional().describe(
    "Proposed action. Runs action-policy rules (blocked commands/paths, requireTests, maxFilesPerChange)."
  )
});
async function runCheckStandards(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  if (!input.plan && !input.action) {
    throw new Error("Provide either `plan` or `action` to check.");
  }
  return client.post("/api/v1/mcp/check-standards", {
    projectId,
    plan: input.plan,
    action: input.action
  });
}
var createRequirementInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  kind: z.enum(["epic", "feature", "story", "adr", "test_plan", "release_plan", "incident"]).optional().describe("Plan kind. Defaults to `story` \u2014 the closest analog to a requirement."),
  title: z.string().min(1).describe("One-line title."),
  summary: z.string().optional().describe("1-3 sentence description."),
  body: z.string().optional().describe("Markdown body \u2014 full requirement content."),
  priority: z.enum(["p0", "p1", "p2", "p3"]).optional(),
  effortEstimate: z.string().optional().describe('Free-form, e.g. "3d" or "M".'),
  parentPlanId: z.string().optional().nullable().describe("Parent plan id for stories under features, ADRs under epics, etc."),
  assigneeId: z.string().optional(),
  assigneeName: z.string().optional()
});
async function runCreateRequirement(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  const { projectId: _projectId, ...body } = input;
  return client.post(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/requirements`,
    body
  );
}
var deleteDraftRequirementInput = z.object({
  id: z.string().min(1).describe("Draft id from list_draft_requirements.")
});
async function runDeleteDraftRequirement(_, input) {
  bumpToolCall();
  const removed = deleteDraft(input.id);
  if (!removed) throw new Error(`No draft with id "${input.id}".`);
  return { id: input.id, deleted: true };
}
var draftRequirementInput = z.object({
  kind: z.enum(["epic", "feature", "story", "adr", "test_plan", "release_plan", "incident"]).optional().describe(
    "Plan kind. No implicit default \u2014 pick from the enum based on project state and `recommendedKickoff` guidance. `story` for individual deliverables; `feature` when grouping stories under a feature; `epic` for multi-feature scope."
  ),
  title: z.string().min(1),
  summary: z.string().optional(),
  body: z.string().optional(),
  priority: z.enum(["p0", "p1", "p2", "p3"]).optional(),
  effortEstimate: z.string().optional(),
  parentPlanId: z.string().optional().nullable(),
  assigneeId: z.string().optional(),
  assigneeName: z.string().optional()
});
async function runDraftRequirement(_, input) {
  bumpToolCall();
  const draft = addDraft(input);
  return {
    draft,
    nextStep: "Call `list_draft_requirements` to review, `update_draft_requirement` to edit, or `push_requirements` (no args) to commit all drafts."
  };
}

// src/domain/pipelines/templates.ts
var PIPELINE_PLATFORMS = ["github_actions", "azure_devops", "gitlab_ci", "jenkins"];
var PIPELINE_STACKS = ["node", "python", "java", "go", "dotnet"];

// src/mcp/tools/pipeline/generate-pipeline.ts
var generatePipelineInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  platform: z.enum(PIPELINE_PLATFORMS).describe("Target CI/CD platform."),
  techStack: z.enum(PIPELINE_STACKS).optional().describe("Tech stack hint. Defaults to `node`."),
  includeDocker: z.boolean().optional().describe("Append Docker image build/push stages."),
  includeKubernetes: z.boolean().optional().describe("Append Kubernetes deployment steps.")
});
async function runGeneratePipeline(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  return client.post(`/api/v1/mcp/pipelines/generate`, { ...input, projectId });
}
var TEST_AUTHOR_SLUG = "test-author";
var generateTestsInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  planId: z.string().optional().describe("Optional: file the generated tests against an existing test_plan."),
  context: z.string().optional().describe(
    "What to generate tests for \u2014 e.g. a feature description, an ADR id, a PR diff summary."
  ),
  coverageTarget: z.number().min(0).max(1).optional().describe("Target coverage 0-1 (passed to the skill as a hint).")
});
async function runGenerateTests(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  try {
    return await client.post(`/api/v1/skills/${TEST_AUTHOR_SLUG}/invoke`, {
      input: {
        projectId,
        context: input.context,
        coverageTarget: input.coverageTarget
      },
      entityType: input.planId ? "plan" : void 0,
      entityId: input.planId
    });
  } catch (err) {
    if (err instanceof CozntApiError && err.status === 404) {
      throw new Error(
        `No skill with slug "${TEST_AUTHOR_SLUG}" registered. Either create one on the platform, or call \`invoke_skill\` directly with a skill you have.`
      );
    }
    throw err;
  }
}
var getAssignedWorkInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  assigneeEmail: z.string().optional().describe(
    "Filter to one assignee. For plans this is matched against `assigneeName`; for work_items against `assigneeEmail`."
  )
});
async function runGetAssignedWork(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  const params = new URLSearchParams();
  if (input.assigneeEmail) params.set("assigneeEmail", input.assigneeEmail);
  const qs = params.toString();
  return client.get(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/assigned-work${qs ? `?${qs}` : ""}`
  );
}
var getDesignContextInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runGetDesignContext(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  return client.get(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/design-context`
  );
}
var getMyContextInput = z.object({
  repoUrl: z.string().optional().describe(
    "Optional repo URL hint (e.g. https://github.com/org/repo) so coznt can disambiguate which project this session is for when the API key is org-scoped."
  ),
  workItemKey: z.string().optional().describe(
    "Optional work item key (e.g. JIRA ticket id) the agent thinks it's working on."
  )
});
function readLocalConfig() {
  try {
    const raw = readFileSync(join(process.cwd(), ".coznt", "config.json"), "utf8");
    const parsed = JSON.parse(raw);
    const serverUrl = typeof parsed.serverUrl === "string" ? parsed.serverUrl.replace(/\/$/, "") : null;
    if (!serverUrl) return null;
    const mcp = parsed.mcp ?? null;
    const promptHook = parsed.promptHook ?? null;
    return {
      serverUrl,
      mcpVersion: mcp && typeof mcp.version === "string" ? mcp.version : null,
      hookVersion: promptHook && typeof promptHook.version === "string" ? promptHook.version : null
    };
  } catch {
    return null;
  }
}
async function fetchLatestVersion(serverUrl, slug) {
  try {
    const res = await fetch(`${serverUrl}/install/${slug}/latest`, { redirect: "manual" });
    const location = res.headers.get("location");
    if (!location) return null;
    const match = location.match(new RegExp(`${slug}-(.+)\\.tgz$`));
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
async function computeStaleness() {
  const cfg = readLocalConfig();
  if (!cfg) return null;
  const [latestMcp, latestHook] = await Promise.all([
    fetchLatestVersion(cfg.serverUrl, "coznt-mcp"),
    fetchLatestVersion(cfg.serverUrl, "coznt-prompt-hook")
  ]);
  const reasons = [];
  const drift = (component, local, latest) => {
    if (local && latest && local !== latest) {
      reasons.push({ component, local, latest });
    }
  };
  drift("coznt-mcp", cfg.mcpVersion, latestMcp);
  drift("coznt-prompt-hook", cfg.hookVersion, latestHook);
  const shouldSync = reasons.length > 0;
  const message = shouldSync ? `Coznt artifacts have drifted (${reasons.map((r) => `${r.component} ${r.local} \u2192 ${r.latest}`).join("; ")}). Ask the user to run \`coznt sync\` to refresh posture and choreography.` : null;
  return { shouldSync, reasons, message };
}
async function runGetMyContext(client, input) {
  bumpToolCall();
  const params = new URLSearchParams();
  if (input.repoUrl) params.set("repoUrl", input.repoUrl);
  if (input.workItemKey) params.set("workItemKey", input.workItemKey);
  const qs = params.toString();
  const path3 = `/api/v1/mcp/context${qs ? `?${qs}` : ""}`;
  const bodyPromise = client.get(path3);
  const stalenessPromise = computeStaleness().catch(() => null);
  const body = await bodyPromise;
  const staleness = await stalenessPromise;
  if (staleness && typeof body === "object" && body !== null && !Array.isArray(body)) {
    return { ...body, staleness };
  }
  return body;
}
var setProjectInput = z.object({
  project: z.string().min(1).describe("Project id, slug, or name to bind to this session. Fuzzy-matched.")
});
async function runSetProject(client, input) {
  bumpToolCall();
  process.stderr.write(
    `[coznt-mcp] set_project: resolving query=${JSON.stringify(input.project)}
`
  );
  const result = await client.post(
    "/api/v1/mcp/projects/resolve",
    { query: input.project }
  );
  setSessionProject(result.project);
  process.stderr.write(
    `[coznt-mcp] set_project: bound project=${result.project.slug} id=${result.project.id}
`
  );
  return {
    bound: true,
    project: result.project,
    note: `Session bound to "${result.project.name}" (slug: ${result.project.slug}). Subsequent verbs read from this project until you call \`switch_project\` or end the session.`
  };
}
var switchProjectInput = z.object({
  project: z.string().min(1).optional().describe(
    "Project id / slug / name to switch to. Omit to clear the current binding (next call rebinds from the API key default)."
  )
});
async function runSwitchProject(client, input) {
  bumpToolCall();
  if (!input.project) {
    const session = getCurrentSession();
    const prior = session?.project?.slug ?? "<none>";
    if (session) session.project = null;
    process.stderr.write(
      `[coznt-mcp] switch_project: CLEARED prior=${prior}
`
    );
    return {
      bound: false,
      note: "Session project binding cleared. Next verb call will rebind from the API key default if one is configured."
    };
  }
  process.stderr.write(
    `[coznt-mcp] switch_project: resolving query=${JSON.stringify(input.project)}
`
  );
  const result = await client.post(
    "/api/v1/mcp/projects/resolve",
    { query: input.project }
  );
  setSessionProject(result.project);
  process.stderr.write(
    `[coznt-mcp] switch_project: bound project=${result.project.slug} id=${result.project.id}
`
  );
  return {
    bound: true,
    project: result.project,
    note: `Session switched to "${result.project.name}" (slug: ${result.project.slug}).`
  };
}
var getOutcomesInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  skillSlug: z.string().optional().describe("Optional filter to a single skill."),
  limit: z.number().int().min(1).max(100).optional().describe("Default 20, max 100.")
});
async function runGetOutcomes(client, input) {
  bumpToolCall();
  const params = new URLSearchParams();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (projectId) params.set("projectId", projectId);
  if (input.skillSlug) params.set("skillSlug", input.skillSlug);
  if (input.limit) params.set("limit", String(input.limit));
  const qs = params.toString();
  return client.get(`/api/v1/mcp/outcomes${qs ? `?${qs}` : ""}`);
}
var getPipelineStatusInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runGetPipelineStatus(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  return client.get(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/pipeline-status`
  );
}

// src/db/schema/plan/plan-kinds.ts
var PLAN_KINDS = [
  "epic",
  "feature",
  "story",
  "spec",
  "adr",
  "test_plan",
  "release_plan",
  "risk_register",
  "incident"
];
var PLAN_STATUSES = [
  "draft",
  "in_review",
  "approved",
  "in_progress",
  "completed",
  "rejected",
  "changes_requested",
  "cancelled"
];

// src/mcp/tools/plan/get-plans.ts
var getPlansInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  id: z.string().optional().describe("Specific plan id to fetch full content for. Omit to list."),
  kind: z.enum(PLAN_KINDS).optional().describe("Optional filter by document type."),
  status: z.enum(PLAN_STATUSES).optional().describe("Optional status filter."),
  slug: z.string().optional().describe("Optional exact-slug filter."),
  includeBody: z.boolean().optional().describe("List mode: embed full markdown body in each row (default: metadata only)."),
  limit: z.number().int().min(1).max(200).optional().describe("Default 50, max 200.")
});
async function runGetPlans(client, input) {
  bumpToolCall();
  if (input.id) {
    return client.get(`/api/v1/mcp/plans/${encodeURIComponent(input.id)}`);
  }
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  const params = new URLSearchParams();
  params.set("projectId", projectId);
  if (input.kind) params.set("kind", input.kind);
  if (input.status) params.set("status", input.status);
  if (input.slug) params.set("slug", input.slug);
  if (input.includeBody) params.set("includeBody", "true");
  if (input.limit) params.set("limit", String(input.limit));
  return client.get(`/api/v1/mcp/plans?${params.toString()}`);
}
var getProjectStatusInput = z.object({
  projectId: z.string().optional().describe(
    "Project id. Optional \u2014 defaults to the session's bound project (auto-resolved from the API key)."
  )
});
async function runGetProjectStatus(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error(
      "No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly."
    );
  }
  return client.get(`/api/v1/mcp/projects/${encodeURIComponent(projectId)}/status`);
}
var getRequirementsInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  kind: z.enum(["epic", "feature", "story", "adr", "test_plan", "release_plan", "incident"]).optional().describe("Plan kind to list. Defaults to `story` (the closest analog to a requirement)."),
  status: z.enum([
    "draft",
    "in_review",
    "approved",
    "in_progress",
    "completed",
    "rejected",
    "cancelled"
  ]).optional().describe("Optional status filter."),
  limit: z.number().int().min(1).max(200).optional().describe("Default 50, max 200.")
});
async function runGetRequirements(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  const params = new URLSearchParams();
  if (input.kind) params.set("kind", input.kind);
  if (input.status) params.set("status", input.status);
  if (input.limit) params.set("limit", String(input.limit));
  const qs = params.toString();
  return client.get(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/requirements${qs ? `?${qs}` : ""}`
  );
}
var requirementPrioritySchema = z.enum(["p0", "p1", "p2", "p3"]);
var nonEmpty = z.string().trim().min(1);
var requirementsMdInputSchema = z.object({
  projectId: z.string().optional(),
  productName: nonEmpty.describe("Product name."),
  productSummary: nonEmpty.describe("One-line summary of the product."),
  problemStatement: nonEmpty.describe("Problem statement."),
  idealTargetUser: nonEmpty.describe("Ideal target user."),
  primaryUserPersona: nonEmpty.describe("Primary user persona."),
  howProductHelps: nonEmpty.describe("How this product helps this specific user type."),
  features: z.array(
    z.object({
      name: nonEmpty,
      description: nonEmpty,
      priority: requirementPrioritySchema
    })
  ).min(1).max(3).describe("One to three core features with descriptions and priorities."),
  integrations: z.array(
    z.object({
      name: nonEmpty,
      description: nonEmpty
    })
  ).min(1).describe('Third-party APIs/apps to integrate. Use name "None" with a brief description if none.'),
  timeline: nonEmpty.describe("Ideal timeline for the project."),
  techStack: nonEmpty.describe("Required or preferred tech stack."),
  budgetConstraints: nonEmpty.describe('Budget constraints. Use "No known budget constraints" if none.'),
  outOfScope: z.array(nonEmpty).min(1).describe("Clear instructions for what is out of scope right now."),
  edgeCases: z.array(nonEmpty).min(1).describe('Known edge cases. Use "No known edge cases currently" if none.')
});
function renderRequirementsMarkdown(input) {
  const featureLines = input.features.map(
    (feature, index) => `### ${index + 1}. ${feature.name}
Priority: ${feature.priority.toUpperCase()}

${feature.description}`
  ).join("\n\n");
  const integrationLines = input.integrations.map((integration) => `### ${integration.name}
${integration.description}`).join("\n\n");
  const outOfScopeLines = input.outOfScope.map((item) => `- ${item}`).join("\n");
  const edgeCaseLines = input.edgeCases.map((item) => `- ${item}`).join("\n");
  return [
    "# Requirements.md",
    "",
    "## Product",
    "### Product Name",
    input.productName,
    "",
    "### One-Line Summary",
    input.productSummary,
    "",
    "## Problem Statement",
    input.problemStatement,
    "",
    "## Ideal Target User",
    input.idealTargetUser,
    "",
    "## User Persona",
    "### Primary User Persona",
    input.primaryUserPersona,
    "",
    "### How This Product Helps This User",
    input.howProductHelps,
    "",
    "## Core Features",
    featureLines,
    "",
    "## Integrations",
    integrationLines,
    "",
    "## Timeline",
    input.timeline,
    "",
    "## Constraints",
    "### Tech Stack",
    input.techStack,
    "",
    "### Budget Constraints",
    input.budgetConstraints,
    "",
    "## Outer Frame / Out Of Scope",
    outOfScopeLines,
    "",
    "## Edge Cases",
    edgeCaseLines,
    ""
  ].join("\n");
}
function missingRequirementsQuestions(error) {
  return error.issues.map((issue) => {
    const path3 = issue.path.join(".");
    if (!path3) return issue.message;
    return `${path3}: ${issue.message}`;
  });
}

// src/mcp/tools/requirement/generate-requirements-md.ts
var generateRequirementsMdInput = requirementsMdInputSchema.partial().extend({
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runGenerateRequirementsMd(client, input) {
  bumpToolCall();
  const parsed = requirementsMdInputSchema.safeParse(input);
  if (!parsed.success) {
    return {
      status: "needs_input",
      missingFields: parsed.error.issues.map((issue) => issue.path.join(".")).filter(Boolean),
      questions: missingRequirementsQuestions(parsed.error)
    };
  }
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed - verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  const body = renderRequirementsMarkdown({ ...parsed.data});
  const result = await client.post("/api/v1/mcp/plans", {
    projectId,
    kind: "story",
    slug: "requirements",
    title: "Requirements.md",
    summary: parsed.data.productSummary,
    body,
    details: {
      requirements: parsed.data
    },
    changeNote: "Generated requirements.md"
  });
  return {
    status: "saved",
    artifact: {
      kind: "story",
      slug: "requirements",
      title: "Requirements.md"
    },
    result
  };
}
var invokeSkillInput = z.object({
  slug: z.string().min(1).describe("Skill slug (e.g. `test-author`, `change-risk-classifier`)."),
  input: z.record(z.string(), z.unknown()).describe("Freeform JSON input. Shape is documented in the skill's `inputSchema`."),
  entityType: z.string().optional().describe("Optional: file result against this entity type (plan / work_item / \u2026)."),
  entityId: z.string().optional().describe("Optional: file result against this entity id."),
  model: z.string().optional().describe("Optional model id override. Defaults to the skill's configured model.")
});
async function runInvokeSkill(client, input) {
  bumpToolCall();
  return client.post(
    `/api/v1/skills/${encodeURIComponent(input.slug)}/invoke`,
    {
      input: input.input,
      entityType: input.entityType,
      entityId: input.entityId,
      model: input.model
    }
  );
}
var listChoreographiesInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runListChoreographies(client, input) {
  bumpToolCall();
  const params = new URLSearchParams();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (projectId) params.set("projectId", projectId);
  const qs = params.toString();
  return client.get(`/api/v1/mcp/choreographies${qs ? `?${qs}` : ""}`);
}
var listCustomChoreographiesInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runListCustomChoreographies(client, input) {
  bumpToolCall();
  const params = new URLSearchParams();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (projectId) params.set("projectId", projectId);
  const qs = params.toString();
  return client.get(`/api/v1/mcp/choreographies/custom${qs ? `?${qs}` : ""}`);
}
var ACTOR_TYPES = ["user", "api", "system", "agent"];
var searchAuditInput = z.object({
  query: z.string().min(1),
  actorType: z.enum(ACTOR_TYPES).optional(),
  fromIso: z.string().optional(),
  toIso: z.string().optional(),
  limit: z.number().int().min(1).max(500).optional().describe("Default 50, max 500.")
});
async function runSearchAudit(client, input) {
  bumpToolCall();
  return client.post(`/api/v1/mcp/search/audit`, {
    query: input.query,
    actorType: input.actorType,
    fromIso: input.fromIso,
    toIso: input.toIso,
    limit: input.limit
  });
}
var searchLearningsInput = z.object({
  query: z.string().min(1).describe("Free-form query \u2014 semantic match against learning bodies."),
  projectId: z.string().optional().describe("Defaults to the session's bound project; pass null for org-wide."),
  limit: z.number().int().min(1).max(100).optional().describe("Default 20, max 100."),
  mode: z.enum(["hybrid", "vector", "keyword"]).optional().describe(
    "Search mode. `hybrid` (default) = vector + BM25. `vector` = semantic only. `keyword` = BM25 only."
  )
});
async function runSearchLearnings(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post(`/api/v1/mcp/search/learnings`, {
    query: input.query,
    projectId,
    limit: input.limit,
    mode: input.mode
  });
}
var VERDICTS = ["success", "rolled_back", "incident"];
var searchOutcomesInput = z.object({
  query: z.string().min(1).describe("Free-form text \u2014 matched against the outcome's rationale."),
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  verdicts: z.array(z.enum(VERDICTS)).optional(),
  fromIso: z.string().optional().describe("ISO-8601 timestamp \u2014 start of search window."),
  toIso: z.string().optional().describe("ISO-8601 timestamp \u2014 end of search window."),
  limit: z.number().int().min(1).max(100).optional()
});
async function runSearchOutcomes(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post(`/api/v1/mcp/search/outcomes`, {
    query: input.query,
    projectId,
    verdicts: input.verdicts,
    fromIso: input.fromIso,
    toIso: input.toIso,
    limit: input.limit
  });
}
var PLAN_KINDS2 = [
  "epic",
  "feature",
  "story",
  "adr",
  "test_plan",
  "release_plan",
  "incident",
  "dev_summary",
  "go_live_report",
  "storyboard",
  "cicd_pipeline"
];
var PLAN_STATUSES2 = ["draft", "in_review", "approved", "in_progress", "completed"];
var searchPlansInput = z.object({
  query: z.string().min(1),
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  kinds: z.array(z.enum(PLAN_KINDS2)).optional().describe("Narrow to specific plan kinds."),
  statuses: z.array(z.enum(PLAN_STATUSES2)).optional().describe("Narrow to specific statuses."),
  limit: z.number().int().min(1).max(100).optional(),
  mode: z.enum(["hybrid", "vector", "keyword"]).optional()
});
async function runSearchPlans(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post(`/api/v1/mcp/search/plans`, {
    query: input.query,
    projectId,
    kinds: input.kinds,
    statuses: input.statuses,
    limit: input.limit,
    mode: input.mode
  });
}
var syncChoreographiesInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  slugs: z.array(z.string()).optional().describe(
    "Optional subset of choreography slugs to fetch. Order is preserved in the response. Unknown slugs error."
  )
});
async function runSyncChoreographies(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post(`/api/v1/mcp/choreographies/sync`, {
    projectId,
    slugs: input.slugs
  });
}
var listDraftRequirementsInput = z.object({});
async function runListDraftRequirements(_, __) {
  bumpToolCall();
  const drafts = listDrafts();
  return {
    total: drafts.length,
    drafts,
    nextStep: drafts.length === 0 ? "No drafts. Use `draft_requirement` to compose one locally before pushing to the platform." : "Use `push_requirements` (no args) to commit all drafts to the platform, or `update_draft_requirement` to edit one."
  };
}
var logDecisionInput = z.object({
  projectId: z.string().min(1).describe("Coznt project id (from get_my_context)."),
  title: z.string().min(1).describe("Short ADR title \u2014 should describe the decision, not the question."),
  summary: z.string().min(1).describe("1-3 sentence summary of the decision."),
  body: z.string().optional().describe(
    "Full markdown body. Suggested sections: Context, Decision, Consequences, Alternatives Considered."
  ),
  assigneeName: z.string().optional().describe("Who's accountable for the decision.")
});
async function runLogDecision(client, input) {
  bumpToolCall();
  return client.post("/api/v1/mcp/decisions", input);
}
var itemSchema = z.object({
  kind: z.enum(["epic", "feature", "story", "adr", "test_plan", "release_plan", "incident"]).optional(),
  title: z.string().min(1),
  summary: z.string().optional(),
  body: z.string().optional(),
  priority: z.enum(["p0", "p1", "p2", "p3"]).optional(),
  effortEstimate: z.string().optional(),
  parentPlanId: z.string().optional().nullable(),
  assigneeId: z.string().optional(),
  assigneeName: z.string().optional()
});
var pushRequirementsInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  items: z.array(itemSchema).min(1).max(50).optional().describe(
    "Inline items to create (1-50). Omit to push the session's draft_requirement set instead."
  )
});
async function runPushRequirements(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  let payload;
  let pushedDrafts = false;
  if (input.items && input.items.length > 0) {
    payload = input.items;
  } else {
    const drafts = listDrafts();
    if (drafts.length === 0) {
      throw new Error(
        "No `items` passed and no session drafts to push. Use `draft_requirement` to compose drafts, or pass `items` inline."
      );
    }
    payload = drafts.map(({ id: _id, createdAt: _c, updatedAt: _u, ...rest }) => {
      return rest;
    });
    pushedDrafts = true;
  }
  const result = await client.post(
    `/api/v1/mcp/projects/${encodeURIComponent(projectId)}/requirements`,
    payload
  );
  if (pushedDrafts) clearDrafts();
  return { ...result ?? {}, pushedDrafts };
}
var sessionEndInput = z.object({
  outcome: z.enum(["completed", "abandoned"]).default("completed").describe("Did the session reach a coherent endpoint, or was it abandoned?"),
  summary: z.string().optional().describe("1-2 sentence wrap-up the agent wants to record.")
});
async function runSessionEnd(client, input) {
  const session = getCurrentSession();
  if (!session?.serverId) {
    return { ended: false, reason: "no_active_session" };
  }
  const ended = endLocalSession();
  await client.post(`/api/v1/mcp/sessions/${encodeURIComponent(session.serverId)}/end`, {
    outcome: input.outcome,
    summary: input.summary ?? null,
    toolCalls: ended?.toolCalls ?? 0,
    durationMs: ended ? ended.endedAt.getTime() - ended.startedAt.getTime() : 0
  });
  return { ended: true, sessionId: session.serverId };
}
var sessionStartInput = z.object({
  intent: z.string().optional().describe(
    'What the agent is about to do ("reviewing PR #42", "drafting ADR for X"). Helps a human auditor scan the audit log later.'
  ),
  repoUrl: z.string().optional().describe("Optional repo hint for project resolution.")
});
async function runSessionStart(client, input) {
  const local = startLocalSession(input.intent ?? null);
  const res = await client.post("/api/v1/mcp/sessions", {
    intent: input.intent ?? null,
    repoUrl: input.repoUrl ?? null,
    localId: local.localId
  });
  attachServerId(res.id);
  return { sessionId: res.id, startedAt: res.createdAt };
}
var updateDraftRequirementInput = z.object({
  id: z.string().min(1).describe("Draft id from list_draft_requirements."),
  kind: z.enum(["epic", "feature", "story", "adr", "test_plan", "release_plan", "incident"]).optional(),
  title: z.string().optional(),
  summary: z.string().optional(),
  body: z.string().optional(),
  priority: z.enum(["p0", "p1", "p2", "p3"]).optional(),
  effortEstimate: z.string().optional(),
  parentPlanId: z.string().optional().nullable(),
  assigneeId: z.string().optional(),
  assigneeName: z.string().optional()
});
async function runUpdateDraftRequirement(_, input) {
  bumpToolCall();
  const { id, ...patch } = input;
  const updated = updateDraft(id, patch);
  if (!updated) throw new Error(`No draft with id "${id}".`);
  return { draft: updated };
}
var updateTestResultInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  planId: z.string().optional().describe("Optional test_plan id this run executes."),
  suite: z.string().optional().describe('Suite name, e.g. "unit", "e2e".'),
  commitSha: z.string().optional(),
  branch: z.string().optional(),
  status: z.enum(["passed", "failed", "errored", "skipped"]),
  total: z.number().int().nonnegative(),
  passed: z.number().int().nonnegative(),
  failed: z.number().int().nonnegative(),
  skipped: z.number().int().nonnegative().optional().default(0),
  durationMs: z.number().int().nonnegative().optional(),
  coverage: z.number().min(0).max(1).optional().describe("Reported coverage 0\u20131 (e.g. 0.82 for 82%)."),
  ciRunUrl: z.string().optional()
});
async function runUpdateTestResult(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  return client.post("/api/v1/test-runs", { ...input, projectId });
}
var updateWorkItemStatusInput = z.object({
  workItemId: z.string().min(1).describe("The coznt work_item id (not the external id)."),
  status: z.string().min(1).optional().describe(
    "New status. Free-form string \u2014 coznt doesn't enforce a vocabulary; mirror upstream's enum."
  ),
  assigneeEmail: z.string().email().optional().describe("Reassign to this email.")
});
async function runUpdateWorkItemStatus(client, input) {
  bumpToolCall();
  return client.patch(
    `/api/v1/mcp/work-items/${encodeURIComponent(input.workItemId)}`,
    { status: input.status, assigneeEmail: input.assigneeEmail }
  );
}

// src/domain/short-syntax/parser.ts
var TOKEN_PATTERNS = {
  kind: /(?:^|\s)#([a-z][a-z_]*)/gi,
  project: /(?:^|\s)\+([a-z0-9][a-z0-9-]{2,})/gi,
  dueDate: /(?:^|\s)@(\d{4}-\d{2}-\d{2})\b/g,
  assignee: /(?:^|\s)@([a-z0-9][a-z0-9_.-]*)/gi,
  approval: /(?:^|\s)(?:→|->)approval:([a-z0-9][a-z0-9_.@-]*)/gi,
  estimate: /(?:^|\s)(\d+(?:\.\d+)?)([mhd])\b/gi
};
var ESTIMATE_UNIT_MINUTES = {
  m: 1,
  h: 60,
  d: 60 * 8
  // working day, not calendar day — matches productivity-tool convention
};
function parseShortSyntax(input) {
  const trimmed = input.trim();
  if (trimmed.length === 0) return { title: "" };
  const matches = [];
  for (const [token, regex] of Object.entries(TOKEN_PATTERNS)) {
    regex.lastIndex = 0;
    let m;
    while ((m = regex.exec(trimmed)) !== null) {
      const fullMatch = m[0];
      const leadingOffset = fullMatch.startsWith(" ") ? 1 : 0;
      matches.push({
        token,
        start: m.index + leadingOffset,
        end: m.index + fullMatch.length,
        capture: m[1],
        unit: token === "estimate" ? m[2] : void 0
      });
    }
  }
  const dueDateRanges = matches.filter((m) => m.token === "dueDate");
  const resolved = matches.filter(
    (m) => m.token !== "assignee" || !dueDateRanges.some((d) => d.start <= m.start && m.start < d.end)
  );
  const result = { title: "" };
  let estimateMinutes = 0;
  resolved.sort((a, b) => a.start - b.start);
  for (const m of resolved) {
    switch (m.token) {
      case "kind":
        result.kind = m.capture.toLowerCase();
        break;
      case "project":
        result.projectSlug = m.capture.toLowerCase();
        break;
      case "dueDate":
        result.dueDate = m.capture;
        break;
      case "assignee":
        result.assignee = m.capture.toLowerCase();
        break;
      case "approval":
        result.approvalTarget = m.capture.toLowerCase();
        break;
      case "estimate": {
        const value = Number.parseFloat(m.capture);
        if (Number.isFinite(value) && m.unit) {
          estimateMinutes += value * ESTIMATE_UNIT_MINUTES[m.unit];
        }
        break;
      }
    }
  }
  if (estimateMinutes > 0) result.estimateMinutes = Math.round(estimateMinutes);
  let stripped = trimmed;
  const sorted = [...resolved].sort((a, b) => b.start - a.start);
  for (const m of sorted) {
    stripped = stripped.slice(0, m.start) + stripped.slice(m.end);
  }
  result.title = stripped.replace(/\s+/g, " ").trim();
  return result;
}

// src/mcp/tools/plan/upsert-plan.ts
var upsertPlanInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  kind: z.enum(PLAN_KINDS).optional().describe(
    "Plan kind. Picks the document type: `test_plan` for a test plan, `release_plan` for release notes, `storyboard` for a UI storyboard, etc. May also be derived from `shortSyntax` (`#kind`)."
  ),
  slug: z.string().min(1).regex(/^[a-z0-9][a-z0-9-]*$/).describe(
    "Stable identifier within the project \u2014 used to upsert. Lowercase alphanumerics + hyphens, e.g. `test-plan-q3-2026`."
  ),
  title: z.string().optional().describe(
    "Human-readable title. May also be derived from `shortSyntax` (the leftover prose after stripping tokens)."
  ),
  summary: z.string().optional().describe("One-line summary shown in lists."),
  body: z.string().min(1).describe("Full markdown body. Treated as the new live content on revise."),
  details: z.record(z.string(), z.unknown()).optional().describe("Optional kind-specific structured fields (validated downstream per kind)."),
  parentPlanId: z.string().optional().nullable().describe("Optional rollup parent (e.g. a feature for a test_plan)."),
  changeNote: z.string().optional().describe("Optional note attached to this revision (e.g. 'regenerated after requirements update')."),
  shortSyntax: z.string().optional().describe(
    "Speed-of-thought authoring shorthand. Tokens: `#kind`, `+project-slug`, `@assignee` (or `@YYYY-MM-DD` for due date), `\u2192approval:<target>`, `2h`/`3d`/`30m` estimate. Leftover prose becomes the title. Explicit fields (kind, title) win when both are provided."
  )
});
async function runUpsertPlan(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error("No active project. API key resolution failed \u2014 verify COZNT_API_KEY is valid, or pass `projectId` explicitly.");
  }
  let kind = input.kind;
  let title = input.title;
  if (input.shortSyntax) {
    const parsed = parseShortSyntax(input.shortSyntax);
    if (!kind && parsed.kind && PLAN_KINDS.includes(parsed.kind)) {
      kind = parsed.kind;
    }
    if (!title && parsed.title) title = parsed.title;
  }
  if (!kind) {
    throw new Error("kind is required \u2014 pass `kind` explicitly or include `#kind` in shortSyntax.");
  }
  if (!title) {
    throw new Error("title is required \u2014 pass `title` explicitly or include prose in shortSyntax.");
  }
  const { shortSyntax: _drop, ...rest } = input;
  return client.post(`/api/v1/mcp/plans`, { ...rest, projectId, kind, title });
}
var BUFFER_DIRNAME = ".coznt";
var BUFFER_FILENAME = "prompt-buffer.jsonl";
function getPromptBufferPath(workspaceDir) {
  return path.join(workspaceDir, BUFFER_DIRNAME, BUFFER_FILENAME);
}
async function ensurePromptBufferScaffold(workspaceDir) {
  const dir = path.join(workspaceDir, BUFFER_DIRNAME);
  await promises.mkdir(dir, { recursive: true });
  return getPromptBufferPath(workspaceDir);
}
async function appendToLocalBuffer(workspaceDir, entry) {
  const file = await ensurePromptBufferScaffold(workspaceDir);
  const full = {
    localId: entry.localId ?? randomUUID(),
    capturedAt: entry.capturedAt ?? (/* @__PURE__ */ new Date()).toISOString(),
    projectId: entry.projectId,
    mcpSessionId: entry.mcpSessionId,
    role: entry.role,
    source: entry.source,
    content: entry.content,
    phase: entry.phase,
    authorName: entry.authorName,
    authorUsername: entry.authorUsername,
    authorEmail: entry.authorEmail,
    prescored: entry.prescored
  };
  await promises.appendFile(file, JSON.stringify(full) + "\n", "utf8");
  return full;
}
async function readLocalBuffer(workspaceDir) {
  const file = getPromptBufferPath(workspaceDir);
  try {
    const data = await promises.readFile(file, "utf8");
    return data.split("\n").filter((line) => line.trim().length > 0).map((line) => JSON.parse(line));
  } catch (err) {
    if (err.code === "ENOENT") return [];
    throw err;
  }
}
async function writeLocalBuffer(workspaceDir, entries) {
  const file = await ensurePromptBufferScaffold(workspaceDir);
  await promises.writeFile(
    file,
    entries.map((e) => JSON.stringify(e)).join("\n") + (entries.length ? "\n" : ""),
    "utf8"
  );
}
function runGit(args, cwd) {
  try {
    return execSync(`git ${args.join(" ")}`, {
      cwd,
      stdio: ["ignore", "pipe", "ignore"],
      encoding: "utf8"
    }).trim();
  } catch {
    return null;
  }
}
async function isGitRepo(dir) {
  try {
    await promises.access(path.join(dir, ".git"));
    return true;
  } catch {
    return false;
  }
}
async function resolveVibeAuthor(workspaceDir) {
  const username = os.userInfo().username;
  const envName = process.env.COZNT_PROMPT_AUTHOR?.trim();
  const envEmail = process.env.COZNT_PROMPT_AUTHOR_EMAIL?.trim() || null;
  if (envName) {
    return { authorName: envName, authorEmail: envEmail, authorUsername: username };
  }
  if (await isGitRepo(workspaceDir)) {
    const gitName = runGit(["config", "user.name"], workspaceDir);
    const gitEmail = runGit(["config", "user.email"], workspaceDir);
    if (gitName) {
      return {
        authorName: gitName,
        authorEmail: gitEmail || envEmail,
        authorUsername: username
      };
    }
  }
  return { authorName: username, authorEmail: envEmail, authorUsername: username };
}

// src/mcp/tools/prompt/log-prompt.ts
var logPromptInput = z.object({
  content: z.string().min(1).describe("Prompt text. USER messages typed by the developer."),
  role: z.enum(["USER", "ASSISTANT", "SYSTEM"]).default("USER"),
  source: z.enum(["CURSOR", "CLAUDE_CODE", "COPILOT", "WINDSURF", "CODEX", "OTHER"]).default("CURSOR"),
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  mcpSessionId: z.string().optional().describe("Defaults to the active MCP session id."),
  authorName: z.string().optional(),
  authorUsername: z.string().optional(),
  authorEmail: z.string().optional(),
  clientLocalId: z.string().optional().describe(
    "Idempotency key. The platform de-dupes on (projectId, clientLocalId); reuse a key to upsert."
  ),
  alsoBufferLocally: z.boolean().default(false).describe("Also append to the local JSONL buffer.")
});
async function runLogPrompt(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id ?? null;
  const mcpSessionId = input.mcpSessionId ?? getCurrentSession()?.serverId ?? null;
  const workspaceDir = process.cwd();
  let author = {
    authorName: input.authorName ?? null,
    authorEmail: input.authorEmail ?? null,
    authorUsername: input.authorUsername ?? null
  };
  if (!author.authorName) {
    const resolved = await resolveVibeAuthor(workspaceDir);
    author = {
      authorName: input.authorName ?? resolved.authorName,
      authorEmail: input.authorEmail ?? resolved.authorEmail,
      authorUsername: input.authorUsername ?? resolved.authorUsername
    };
  }
  const clientLocalId = input.clientLocalId ?? randomUUID();
  const payload = {
    projectId,
    mcpSessionId,
    role: input.role,
    source: input.source,
    content: input.content,
    authorName: author.authorName,
    authorUsername: author.authorUsername,
    authorEmail: author.authorEmail,
    clientLocalId
  };
  try {
    const res = await client.post("/api/v1/mcp/prompts", payload);
    if (input.alsoBufferLocally) {
      await appendToLocalBuffer(workspaceDir, {
        ...payload,
        phase: null,
        prescored: null,
        localId: clientLocalId
      }).catch(() => void 0);
    }
    return { ...res, buffered: false };
  } catch (err) {
    const buffered = await appendToLocalBuffer(workspaceDir, {
      ...payload,
      phase: null,
      prescored: null,
      localId: clientLocalId
    });
    return {
      id: null,
      created: false,
      buffered: true,
      localId: buffered.localId,
      reason: err instanceof Error ? err.message : String(err)
    };
  }
}
var ratePromptInput = z.object({
  content: z.string().min(1).optional().describe("Inline content to score."),
  promptLogId: z.string().optional().describe("Re-score an existing prompt-log row."),
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
}).refine((d) => Boolean(d.content) !== Boolean(d.promptLogId), {
  message: "Provide exactly one of `content` or `promptLogId`"
});
async function runRatePrompt(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post("/api/v1/mcp/score-prompt", {
    content: input.content,
    promptLogId: input.promptLogId,
    projectId
  });
}
var getPromptAuthorInput = z.object({
  workspaceDir: z.string().optional().describe("Workspace directory. Defaults to the MCP client's CWD.")
});
async function runGetPromptAuthor(_unused, input) {
  bumpToolCall();
  return resolveVibeAuthor(input.workspaceDir ?? process.cwd());
}
var flushLocalPromptsInput = z.object({
  projectId: z.string().optional().describe("Defaults to the session's bound project."),
  workspaceDir: z.string().optional().describe("Workspace directory. Defaults to CWD.")
});
async function runFlushLocalPrompts(client, input) {
  bumpToolCall();
  const workspaceDir = input.workspaceDir ?? process.cwd();
  const fallbackProjectId = getSessionProject()?.id ?? null;
  const entries = await readLocalBuffer(workspaceDir);
  if (entries.length === 0) {
    return { flushed: 0, errors: [] };
  }
  const remaining = [];
  const errors = [];
  let flushed = 0;
  for (const entry of entries) {
    const projectId = entry.projectId ?? input.projectId ?? fallbackProjectId;
    try {
      await client.post("/api/v1/mcp/prompts", {
        projectId,
        mcpSessionId: entry.mcpSessionId,
        role: entry.role,
        source: entry.source,
        content: entry.content,
        phase: entry.phase,
        authorName: entry.authorName,
        authorUsername: entry.authorUsername,
        authorEmail: entry.authorEmail,
        clientLocalId: entry.localId,
        prescored: entry.prescored
      });
      flushed++;
    } catch (err) {
      remaining.push(entry);
      errors.push({ localId: entry.localId, reason: err instanceof Error ? err.message : String(err) });
    }
  }
  await writeLocalBuffer(workspaceDir, remaining);
  return { flushed, errors };
}
var triggerPipelineInput = z.object({
  source: z.enum(["GITHUB", "AZURE_DEVOPS"]).describe("Which CI provider to trigger."),
  workflowId: z.string().min(1).describe(
    "GitHub: workflow filename (e.g. 'ci.yml') or numeric id. ADO: numeric pipeline id (as string)."
  ),
  branch: z.string().optional().describe("Ref to dispatch against. Default: 'main'."),
  projectId: z.string().optional().describe("Defaults to the session's bound project.")
});
async function runTriggerPipeline(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  if (!projectId) {
    throw new Error(
      "No active project. Pass `projectId` or bind a project-scoped API key."
    );
  }
  return client.post("/api/v1/mcp/trigger-pipeline", {
    projectId,
    source: input.source,
    workflowId: input.workflowId,
    branch: input.branch
  });
}
var getAutonomyInput = z.object({
  skillSlug: z.string().optional().describe(
    "Optional skill slug (e.g. `change-risk-classifier`). When provided, returns autonomy for that skill on the current project plus an across-projects breakdown. Omit for the project-wide aggregate."
  ),
  projectId: z.string().optional().describe(
    "Optional projectId. Defaults to the session's bound project (auto-resolved from the API key)."
  )
});
async function runGetAutonomy(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  const params = new URLSearchParams();
  if (input.skillSlug) params.set("skillSlug", input.skillSlug);
  if (projectId) params.set("projectId", projectId);
  const query = params.toString();
  return client.get(`/api/v1/mcp/autonomy${query ? `?${query}` : ""}`);
}
var getVerificationDebtInput = z.object({
  projectId: z.string().optional().describe(
    "Optional projectId. Defaults to the session's bound project (auto-resolved from the API key)."
  )
});
async function runGetVerificationDebt(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  const params = new URLSearchParams();
  if (projectId) params.set("projectId", projectId);
  const query = params.toString();
  return client.get(`/api/v1/mcp/verification-debt${query ? `?${query}` : ""}`);
}
var getProvenanceInput = z.object({
  projectId: z.string().optional().describe(
    "Optional projectId. Defaults to the session's bound project (auto-resolved from the API key)."
  ),
  windowDays: z.number().int().min(1).max(365).optional().describe("Trailing window in days. Defaults to 30.")
});
async function runGetProvenance(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  const params = new URLSearchParams();
  if (projectId) params.set("projectId", projectId);
  if (input.windowDays !== void 0) params.set("windowDays", String(input.windowDays));
  const query = params.toString();
  return client.get(`/api/v1/mcp/provenance${query ? `?${query}` : ""}`);
}
var submitPlanForReviewInput = z.object({
  planArtifactId: z.string().min(1).describe("Id of the plan_artifact to move into review.")
});
async function runSubmitPlanForReview(client, input) {
  bumpToolCall();
  return client.post(
    "/api/v1/mcp/governance/submit-plan-for-review",
    input
  );
}

// src/db/schema/evidence-kinds.ts
var EVIDENCE_TYPES = [
  "deployment",
  "test_run",
  "metric_snapshot",
  "work_item",
  "skill_outcome",
  "incident",
  "external_link"
];
var EVIDENCE_ROLES = [
  "implements",
  "validates",
  "deploys",
  "observes",
  "causes"
];

// src/mcp/tools/governance/attach-evidence.ts
var attachEvidenceInput = z.object({
  planArtifactId: z.string().min(1).describe("Plan artifact to attach evidence to."),
  evidenceType: z.enum(EVIDENCE_TYPES).describe(
    "Type of evidence. For internal coznt rows pass `evidenceId`; for external systems pass `externalUrl`."
  ),
  evidenceId: z.string().optional().describe("Id of the internal row (deployment / test_run / work_item / etc.)."),
  externalUrl: z.string().url().optional().describe("URL when the evidence lives outside coznt."),
  role: z.enum(EVIDENCE_ROLES).optional().describe("Semantic role of the evidence relative to the plan."),
  note: z.string().optional().describe("Free-form note from the attacher.")
});
async function runAttachEvidence(client, input) {
  bumpToolCall();
  return client.post("/api/v1/mcp/governance/attach-evidence", input);
}
var requestExceptionInput = z.object({
  governanceRecordId: z.string().min(1).describe("Id of the failing or pending governance_record the exception supersedes."),
  reason: z.string().min(1).describe("Why an exception is being requested."),
  expiresAt: z.string().describe("ISO-8601 timestamp at which the exception expires.")
});
async function runRequestException(client, input) {
  bumpToolCall();
  return client.post("/api/v1/mcp/governance/request-exception", input);
}

// src/db/schema/governance/governance-kinds.ts
var GOVERNANCE_KINDS = ["gate", "approval", "review", "exception"];
var GOVERNANCE_RECORD_STATUSES = [
  "pending",
  "passed",
  "failed",
  "skipped",
  "expired"
];

// src/mcp/tools/governance/list-governance-records.ts
var listGovernanceRecordsInput = z.object({
  planArtifactId: z.string().min(1).describe("Plan artifact whose records to list."),
  kind: z.enum(GOVERNANCE_KINDS).optional().describe("Filter by record kind."),
  status: z.enum(GOVERNANCE_RECORD_STATUSES).optional().describe("Filter by status.")
});
async function runListGovernanceRecords(client, input) {
  bumpToolCall();
  const params = new URLSearchParams();
  params.set("planArtifactId", input.planArtifactId);
  if (input.kind) params.set("kind", input.kind);
  if (input.status) params.set("status", input.status);
  return client.get(
    `/api/v1/mcp/governance/list-governance-records?${params.toString()}`
  );
}
var createGovernanceRecordInput = z.object({
  planArtifactId: z.string().min(1),
  kind: z.enum(GOVERNANCE_KINDS).describe("Record kind."),
  policyId: z.string().optional().describe("Policy that generated this record (if any)."),
  transitionFrom: z.enum(PLAN_STATUSES).optional(),
  transitionTo: z.enum(PLAN_STATUSES).optional(),
  details: z.record(z.string(), z.unknown()).optional().describe(
    "Kind-specific payload. Approval: { approverIds, requiredCount, requestedById }. Gate: { type, threshold, validator }. Review: { findings, reviewerRole }. Exception: { reason, supersedesRecordId, expiresAt }."
  )
});
async function runCreateGovernanceRecord(client, input) {
  bumpToolCall();
  return client.post(
    "/api/v1/mcp/governance/create-governance-record",
    input
  );
}
var decideGovernanceRecordInput = z.object({
  id: z.string().min(1).describe("Governance record id."),
  decision: z.enum(GOVERNANCE_RECORD_STATUSES).refine((s) => s !== "pending", { message: "decision must be terminal" }).describe("Terminal status. `pending` is not a decision."),
  note: z.string().optional().describe("Free-form decision note."),
  detailsPatch: z.record(z.string(), z.unknown()).optional().describe("Optional details merge (e.g. exception approvers).")
});
async function runDecideGovernanceRecord(client, input) {
  bumpToolCall();
  return client.post(
    "/api/v1/mcp/governance/decide-governance-record",
    input
  );
}
var pushPlanToJiraInput = z.object({
  planId: z.string().min(1).describe("The Coznt plan_artifact id to push into Jira.")
});
async function runPushPlanToJira(client, input) {
  bumpToolCall();
  return client.post("/api/v1/mcp/integrations/jira/push-plan", input);
}
var syncJiraWorkItemsInput = z.object({
  projectId: z.string().min(1).optional().describe("Defaults to the session's bound project.")
});
async function runSyncJiraWorkItems(client, input) {
  bumpToolCall();
  const projectId = input.projectId ?? getSessionProject()?.id;
  return client.post("/api/v1/mcp/integrations/jira/sync-work-items", {
    projectId
  });
}

// src/mcp/registry.ts
function tool(def) {
  return def;
}
var tools = [
  tool({
    name: "set_project",
    description: [
      "Bind the session to a project by id, slug, or name. Fuzzy-matches",
      "within the API key's org. NOT NEEDED at session start \u2014 the dispatcher",
      "auto-binds to the API key's pinned project on the first non-optional",
      "verb. Call this only when you need to operate on a project OTHER than",
      "the key's default."
    ].join(" "),
    schema: setProjectInput,
    run: runSetProject
  }),
  tool({
    name: "switch_project",
    description: [
      "Switch the session to a different project mid-conversation, or",
      "omit `project` to clear the binding entirely (next call rebinds",
      "from the API key default if one is set). Same fuzzy matcher as",
      "set_project."
    ].join(" "),
    schema: switchProjectInput,
    run: runSwitchProject
  }),
  tool({
    name: "get_my_context",
    description: [
      "Orient at session start. Returns the active project (id, name,",
      "description), a `welcome` block (headline, summary, nextActions) for",
      "first-message greeting, active rules, available skills with their",
      "per-project autonomy levels, recent ADRs, pinned learnings, and a",
      "recommendedKickoff when one applies. Call this FIRST in any session \u2014",
      "every other tool's behavior depends on what's in the response."
    ].join(" "),
    schema: getMyContextInput,
    run: runGetMyContext
  }),
  tool({
    name: "get_project_status",
    description: [
      `Compact "where are we?" snapshot for the session's bound project.`,
      "Returns governance_record counts (total / passed / failed / pending /",
      "skipped), open-approvals count, and last-deploy info. Use for the",
      "quick check before starting work. For the full briefing (rules,",
      "skills, ADRs) use get_my_context instead."
    ].join(" "),
    schema: getProjectStatusInput,
    run: runGetProjectStatus
  }),
  tool({
    name: "get_requirements",
    description: [
      "List requirement-like plans for the project. Coznt has no",
      "`requirement` plan kind \u2014 defaults to `story` (the closest analog).",
      "Pass `kind` to list other plan types (epic, feature, adr,",
      "test_plan, release_plan, incident)."
    ].join(" "),
    schema: getRequirementsInput,
    run: runGetRequirements
  }),
  tool({
    name: "generate_requirements_md",
    description: [
      "Create or update the canonical requirements.md artifact for the",
      "project. Requires product name, one-line summary, problem statement,",
      "target user, primary persona, 1-3 prioritized core features,",
      "integrations, timeline, tech stack, budget constraints, out-of-scope",
      "boundaries, and edge cases. If any section is missing, returns",
      "status=needs_input and questions instead of saving."
    ].join(" "),
    schema: generateRequirementsMdInput,
    run: runGenerateRequirementsMd
  }),
  tool({
    name: "get_assigned_work",
    description: [
      "Open work in the project \u2014 in-progress plans + open work_items",
      "(GitHub issues / PRs, Jira tickets, ADO items). Pass",
      "`assigneeEmail` to narrow to one person; default returns all open",
      "work in the project."
    ].join(" "),
    schema: getAssignedWorkInput,
    run: runGetAssignedWork
  }),
  tool({
    name: "check_standards",
    description: [
      "Run project rules against a proposed plan body or proposed action",
      "before it lands. Advisory \u2014 nothing is persisted. Use this to",
      "self-correct before calling a write verb. Provide either `plan`",
      "(runs keyword-presence rules) or `action` (runs action-policy",
      "rules: blocked commands/paths, requireTests, maxFilesPerChange)."
    ].join(" "),
    schema: checkStandardsInput,
    run: runCheckStandards
  }),
  // ── Governance (kind-parameterized — spec §10) ────────────────
  tool({
    name: "submit_plan_for_review",
    description: [
      "Move a plan_artifact from draft \u2192 in_review. Materializes the",
      "governance records (gates / approvals / reviews) that apply to the",
      "transition, per the project's active policies. Replaces the legacy",
      "submit_phase_for_review verb \u2014 governance is plan-bound, not",
      "phase-bound."
    ].join(" "),
    schema: submitPlanForReviewInput,
    run: runSubmitPlanForReview
  }),
  tool({
    name: "attach_evidence",
    description: [
      "Attach proof to a plan_artifact: a deployment, test_run, metric",
      "snapshot, work_item, skill_outcome, incident, or external link.",
      "One verb, type-discriminated by evidenceType \u2014 internal targets",
      "pass evidenceId; external targets pass externalUrl."
    ].join(" "),
    schema: attachEvidenceInput,
    run: runAttachEvidence
  }),
  tool({
    name: "request_exception",
    description: [
      "Open a pending exception governance_record that supersedes a",
      "failing or pending record. Carries reason + expiry. Per spec \xA74",
      "the exception itself still requires approval before it takes effect."
    ].join(" "),
    schema: requestExceptionInput,
    run: runRequestException
  }),
  tool({
    name: "list_governance_records",
    description: [
      "Read governance records targeting one plan_artifact. Optional",
      "filters by kind (gate / approval / review / exception) and status."
    ].join(" "),
    schema: listGovernanceRecordsInput,
    run: runListGovernanceRecords
  }),
  tool({
    name: "create_governance_record",
    description: [
      "Kind-parameterized creator. Spec \xA710: never split governance verbs",
      "by kind. Pass kind plus a details payload (approverIds, threshold,",
      "findings, etc.)."
    ].join(" "),
    schema: createGovernanceRecordInput,
    run: runCreateGovernanceRecord
  }),
  tool({
    name: "decide_governance_record",
    description: [
      "Move a governance_record to a terminal status (passed / failed /",
      "skipped / expired). The underlying op records the decision; the",
      "evaluator dispatcher applies any per-kind side effects."
    ].join(" "),
    schema: decideGovernanceRecordInput,
    run: runDecideGovernanceRecord
  }),
  // ── Tier 2 ────────────────────────────────────────────────────
  tool({
    name: "create_requirement",
    description: [
      "Create one requirement-like plan. Coznt has no `requirement` plan",
      "kind \u2014 defaults to `story` (the closest analog). Pass `kind` to",
      "create epic/feature/test_plan/etc."
    ].join(" "),
    schema: createRequirementInput,
    run: runCreateRequirement
  }),
  tool({
    name: "push_requirements",
    description: [
      "Batch-create up to 50 requirement-like plans in one call. Useful",
      "after the agent has elaborated a list with the user. Defaults each",
      "item's kind to `story` if unspecified."
    ].join(" "),
    schema: pushRequirementsInput,
    run: runPushRequirements
  }),
  tool({
    name: "upsert_plan",
    description: [
      "File an authored markdown document as a plan. Upserts by",
      "(projectId, kind, slug): creates a new draft on first call, appends",
      "a plan_revisions row on subsequent calls with the same key. This is",
      "how generator skills (test-plan-generator, release-notes-generator,",
      "etc.) should land their output \u2014 plans ARE coznt's document",
      "container, kind discriminates the type."
    ].join(" "),
    schema: upsertPlanInput,
    run: runUpsertPlan
  }),
  tool({
    name: "get_plans",
    description: [
      "Two modes: list (omit `id`) returns metadata for plans matching the",
      "filters; fetch (provide `id`) returns full body + revisions +",
      "approvals for that one plan. Use this BEFORE authoring a follow-on",
      "plan \u2014 e.g. fetch approved requirements before running",
      "test-plan-generator."
    ].join(" "),
    schema: getPlansInput,
    run: runGetPlans
  }),
  tool({
    name: "get_design_context",
    description: [
      "Richer view than get_my_context for design/development/testing.",
      "Returns ADRs WITH FULL BODIES (not just titles), active",
      "features+stories, and linked work_items. Use when the agent needs",
      "to consult prior architectural decisions or know what features",
      "are in flight."
    ].join(" "),
    schema: getDesignContextInput,
    run: runGetDesignContext
  }),
  tool({
    name: "update_work_item_status",
    description: [
      "Update a coznt work_item's status and/or assignee. For Jira-sourced",
      "work_items, the platform also attempts to transition the linked Jira",
      "issue to the matching workflow status."
    ].join(" "),
    schema: updateWorkItemStatusInput,
    run: runUpdateWorkItemStatus
  }),
  tool({
    name: "push_plan_to_jira",
    description: [
      "Manually push one Coznt plan into the project's bound Jira project.",
      "Creates a Jira issue on first push and updates the existing issue when",
      "the plan already has a jira externalRef."
    ].join(" "),
    schema: pushPlanToJiraInput,
    run: runPushPlanToJira
  }),
  tool({
    name: "sync_jira_work_items",
    description: [
      "Manually pull the bound Jira project's current issues into Coznt",
      "work_items. Use this when Jira webhooks are not configured yet."
    ].join(" "),
    schema: syncJiraWorkItemsInput,
    run: runSyncJiraWorkItems
  }),
  tool({
    name: "update_test_result",
    description: [
      "Record a test run result (status, counts, coverage). Feeds the",
      "`coverage` and `tests passing` governance-record validators, and",
      "attaches as a `test_run` evidence link to any plan_artifact id."
    ].join(" "),
    schema: updateTestResultInput,
    run: runUpdateTestResult
  }),
  tool({
    name: "get_pipeline_status",
    description: [
      "CI/CD + monitoring view: latest deployment, recent test runs with",
      "pass rate + coverage, active release_plan."
    ].join(" "),
    schema: getPipelineStatusInput,
    run: runGetPipelineStatus
  }),
  tool({
    name: "generate_pipeline",
    description: [
      "Render a CI/CD pipeline config (GitHub Actions, Azure DevOps,",
      "GitLab CI, or Jenkins) tailored to the project's tech stack. Returns",
      "{ filename, content } \u2014 the agent writes content to filename in the",
      "consumer repo. Optional Docker and Kubernetes addons."
    ].join(" "),
    schema: generatePipelineInput,
    run: runGeneratePipeline
  }),
  // ── Tier 3 ────────────────────────────────────────────────────
  tool({
    name: "invoke_skill",
    description: [
      "Run a registered skill against an input. Skills are coznt's unit of",
      "AI-driven work \u2014 each invocation flows through action-policy rules,",
      "records a result, and appends a skill_outcomes row that drives",
      "autonomy recompute. Pass the slug from get_my_context's skills list."
    ].join(" "),
    schema: invokeSkillInput,
    run: runInvokeSkill
  }),
  tool({
    name: "get_outcomes",
    description: [
      "Recent skill_outcomes rows for introspection. Answers questions like",
      '"did my last test-plan-generator run succeed?" without leaving the',
      "IDE. Read-only; defaults to the session's bound project. Omit skillSlug",
      "to see outcomes across every skill on the project."
    ].join(" "),
    schema: getOutcomesInput,
    run: runGetOutcomes
  }),
  tool({
    name: "generate_tests",
    description: [
      'Convenience wrapper that calls invoke_skill with slug="test-author".',
      "Better IDE discoverability than asking agents to find the test-author",
      "skill themselves. Returns a clean error if no such skill exists in",
      "the org."
    ].join(" "),
    schema: generateTestsInput,
    run: runGenerateTests
  }),
  tool({
    name: "draft_requirement",
    description: [
      "Add a requirement-like draft to the session's local working set.",
      "Before using this tool, check `recommendedKickoff` on your most",
      "recent `get_my_context` response \u2014 when set, it points at the",
      "kickoff skill (e.g. feature-spec-generator) that should run first;",
      "calling this tool directly bypasses that routing. Use this tool",
      "only when recommendedKickoff is null or after the kickoff skill",
      "has run. In-memory only \u2014 drafts die with the MCP process. Use",
      "push_requirements (no items) to commit the draft set to the",
      "platform."
    ].join(" "),
    schema: draftRequirementInput,
    run: runDraftRequirement
  }),
  tool({
    name: "list_draft_requirements",
    description: "Return the session's local requirement drafts. Ephemeral \u2014 cleared on push or process exit.",
    schema: listDraftRequirementsInput,
    run: runListDraftRequirements
  }),
  tool({
    name: "update_draft_requirement",
    description: [
      "Patch a session-local draft by its id. Only the fields you pass are",
      "changed; everything else is preserved."
    ].join(" "),
    schema: updateDraftRequirementInput,
    run: runUpdateDraftRequirement
  }),
  tool({
    name: "delete_draft_requirement",
    description: "Remove a session-local draft. No effect on the platform \u2014 drafts only exist in MCP-process memory until pushed.",
    schema: deleteDraftRequirementInput,
    run: runDeleteDraftRequirement
  }),
  tool({
    name: "log_decision",
    description: [
      "Record an Architecture Decision Record. ADRs are stored as",
      'plan_artifact rows with `kind: "adr"`. Governance applies via the',
      "policies attached to ADR transitions, not phase enforcement."
    ].join(" "),
    schema: logDecisionInput,
    run: runLogDecision
  }),
  tool({
    name: "session_start",
    description: [
      "Open a session on coznt's side. Returns a sessionId that's recorded",
      "in the audit log alongside every subsequent tool call. Call this",
      "after get_my_context so the audit trail is complete."
    ].join(" "),
    schema: sessionStartInput,
    run: runSessionStart
  }),
  tool({
    name: "session_end",
    description: [
      "Close the current session and write its summary (outcome, duration,",
      "tool call count) to the audit log. Idempotent \u2014 calling it twice is",
      "safe."
    ].join(" "),
    schema: sessionEndInput,
    run: runSessionEnd
  }),
  tool({
    name: "list_choreographies",
    description: [
      "Distribution: return the choreography manifest for the bound project.",
      "Each entry has `slug`, `version`, `hash` (SHA-256), `description`,",
      "and `minAutonomy`. The `coznt sync` CLI uses this to diff against",
      "local `.lock` files before deciding which choreographies to fetch.",
      "Read-only."
    ].join(" "),
    schema: listChoreographiesInput,
    run: runListChoreographies
  }),
  tool({
    name: "sync_choreographies",
    description: [
      "Distribution: return the full content bundle of choreographies for",
      "the bound project. Pass `slugs` to fetch only a subset (preserves",
      "order; unknown slugs error). The response carries a `manifestHash`",
      "deterministic over the sorted slug\u2192hash map. Read-only."
    ].join(" "),
    schema: syncChoreographiesInput,
    run: runSyncChoreographies
  }),
  tool({
    name: "search_learnings",
    description: [
      "Knowledge: semantic + keyword search over project learnings. Use when",
      "the user asks 'what did we decide about X?' or 'have we noted Y?'.",
      "Returns ranked hits with body, pinned flag, project, and relevance",
      'score. Defaults to hybrid mode (vector + BM25); pass `mode: "vector"`',
      'or `mode: "keyword"` for single-signal search.'
    ].join(" "),
    schema: searchLearningsInput,
    run: runSearchLearnings
  }),
  tool({
    name: "search_plans",
    description: [
      "Knowledge: semantic + keyword search over plans (ADRs, features,",
      "stories, release_plans, etc.). 'Where was that ADR about authn?'",
      "Filter by `kinds` and/or `statuses` to narrow."
    ].join(" "),
    schema: searchPlansInput,
    run: runSearchPlans
  }),
  tool({
    name: "search_outcomes",
    description: [
      "Knowledge: keyword search over skill_outcomes.rationale. 'Have we",
      "seen this failure before?' Filter by verdicts and time range."
    ].join(" "),
    schema: searchOutcomesInput,
    run: runSearchOutcomes
  }),
  tool({
    name: "search_audit",
    description: [
      "Knowledge: keyword search over audit_logs (summary + action).",
      "CISO-style 'show me everything around the v2.3 incident' queries.",
      "Filter by actorType and time range. Ranked by recency."
    ].join(" "),
    schema: searchAuditInput,
    run: runSearchAudit
  }),
  tool({
    name: "list_custom_choreographies",
    description: [
      "Distribution: return the manifest of customer-authored choreographies",
      "for the bound project (project-scoped + org-wide). Companion to",
      "`list_choreographies` which returns platform-shipped entries.",
      "Read-only."
    ].join(" "),
    schema: listCustomChoreographiesInput,
    run: runListCustomChoreographies
  }),
  // ── Agent-loop governance (Tier 1/2) ──────────────────────────
  tool({
    name: "log_prompt",
    description: [
      "Persist a USER / ASSISTANT / SYSTEM message to the agent-loop ledger",
      "so coznt can grade prompt quality and feed the autonomy attenuation",
      "factor. Idempotent on (projectId, clientLocalId). On platform-side",
      "failure, the prompt is buffered to .coznt/prompt-buffer.jsonl and",
      "drained later via `flush_local_prompts`."
    ].join(" "),
    schema: logPromptInput,
    run: runLogPrompt
  }),
  tool({
    name: "rate_prompt",
    description: [
      "Score a prompt against the canonical 6-dimension rubric (clarity,",
      "context, specificity, constraints, phaseFit, safety) without",
      "persisting. Returns overallScore, tier (GOOD / NEEDS_IMPROVEMENT /",
      "POOR), dimension breakdown, suggestions, and flags. Provide either",
      "`content` (inline) or `promptLogId` (re-score an existing row)."
    ].join(" "),
    schema: ratePromptInput,
    run: runRatePrompt
  }),
  tool({
    name: "get_prompt_author",
    description: [
      "Resolve the local developer's identity for prompt attribution.",
      "Reads git config user.name / user.email and OS username; respects",
      "COZNT_PROMPT_AUTHOR / COZNT_PROMPT_AUTHOR_EMAIL env overrides.",
      "Pure-local \u2014 no platform call."
    ].join(" "),
    schema: getPromptAuthorInput,
    run: runGetPromptAuthor
  }),
  tool({
    name: "flush_local_prompts",
    description: [
      "Drain `.coznt/prompt-buffer.jsonl` to the platform. Atomic on success",
      "\u2014 only failed entries remain in the buffer. Returns { flushed, errors }."
    ].join(" "),
    schema: flushLocalPromptsInput,
    run: runFlushLocalPrompts
  }),
  tool({
    name: "trigger_pipeline",
    description: [
      "Actively trigger a CI/CD pipeline run on GitHub Actions or Azure",
      "DevOps for the bound project. Returns the run id (when the provider",
      "exposes one) and queued status."
    ].join(" "),
    schema: triggerPipelineInput,
    run: runTriggerPipeline
  }),
  // ── M-B verification-debt foundation reads ─────────────────────
  tool({
    name: "get_autonomy",
    description: [
      "Read autonomy state for the calling project. Without `skillSlug`,",
      "returns the project-level aggregate (counts at each level, recent",
      "incidents). With `skillSlug`, returns the per-project autonomy for",
      "that skill plus the across-projects breakdown. Read-only."
    ].join(" "),
    schema: getAutonomyInput,
    run: runGetAutonomy
  }),
  tool({
    name: "get_verification_debt",
    description: [
      "Compute the verification-debt score for the calling project.",
      "Derived only from the audit ledger (autonomy distance \xD7 invocations,",
      "open approvals \xD7 age, gate trip rate \xD7 severity, unreviewed AI-authored",
      "changes). Returns total + per-term breakdown. Read-only."
    ].join(" "),
    schema: getVerificationDebtInput,
    run: runGetVerificationDebt
  }),
  tool({
    name: "get_provenance",
    description: [
      "Provenance summary for plans + work_items in the calling project:",
      "AI-authored ratio, per-model count, per-skill count, autonomy",
      "distribution at generation time. Counts only \u2014 never code, never",
      "prompt bodies. Read-only."
    ].join(" "),
    schema: getProvenanceInput,
    run: runGetProvenance
  })
];
var RESOURCES = [
  {
    uri: "coznt://conventions",
    name: "Active conventions and rules",
    description: "The rules coznt enforces for this project (severity, scope, body).",
    mimeType: "application/json",
    read: readConventions
  },
  {
    uri: "coznt://my-tasks",
    name: "Your tasks",
    description: "Work items and open plans visible to this API key.",
    mimeType: "application/json",
    read: readMyTasks
  },
  {
    uri: "coznt://history",
    name: "Recent audit history",
    description: "Last 7 days of audit events for this project.",
    mimeType: "application/json",
    read: readHistory
  }
];

// src/mcp/server.ts
var SERVER_NAME = "coznt-mcp";
var SERVER_VERSION = "0.1.0";
function mcpLog(msg) {
  process.stderr.write(`[coznt-mcp] ${msg}
`);
}
function zodToJsonSchema(schema) {
  return z.toJSONSchema(schema);
}
function createCozntMcpServer() {
  const cfg = readConfig();
  const client = new CozntClient(cfg);
  const server = new Server(
    { name: SERVER_NAME, version: SERVER_VERSION },
    {
      capabilities: {
        tools: {},
        resources: {}
      }
    }
  );
  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: tools.map((t) => ({
      name: t.name,
      description: t.description,
      inputSchema: zodToJsonSchema(t.schema)
    }))
  }));
  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const found = tools.find((t) => t.name === req.params.name);
    if (!found) {
      return {
        content: [{ type: "text", text: `Unknown tool: ${req.params.name}` }],
        isError: true
      };
    }
    const parsed = found.schema.safeParse(req.params.arguments ?? {});
    if (!parsed.success) {
      return {
        content: [{ type: "text", text: `Invalid input: ${parsed.error.message}` }],
        isError: true
      };
    }
    const PROJECT_OPTIONAL_VERBS = /* @__PURE__ */ new Set([
      "set_project",
      "switch_project",
      "get_my_context",
      "draft_requirement",
      "list_draft_requirements",
      "update_draft_requirement",
      "delete_draft_requirement"
    ]);
    if (!getSessionProject() && !PROJECT_OPTIONAL_VERBS.has(req.params.name)) {
      mcpLog(`autobind: attempting /api/v1/mcp/me for verb=${req.params.name}`);
      try {
        const { project } = await client.get("/api/v1/mcp/me");
        setSessionProject(project);
        mcpLog(`autobind: ok project=${project.slug} id=${project.id}`);
      } catch (err) {
        const msg = err instanceof CozntApiError ? `${err.message} (status ${err.status})` : err instanceof Error ? err.message : "unknown error";
        mcpLog(`autobind: FAIL verb=${req.params.name} err=${msg}`);
        return {
          content: [
            {
              type: "text",
              text: `Failed to resolve project from API key: ${msg}. Check that COZNT_API_KEY is valid and bound to a live project, or call \`set_project\` with an id/slug/name to bind one explicitly for this session.`
            }
          ],
          isError: true
        };
      }
    } else if (!PROJECT_OPTIONAL_VERBS.has(req.params.name)) {
      const bound = getSessionProject();
      mcpLog(`dispatch: verb=${req.params.name} bound=${bound?.slug ?? "<none>"}`);
    } else {
      mcpLog(`dispatch: verb=${req.params.name} (project-optional)`);
    }
    try {
      const run = found.run;
      const result = await run(client, parsed.data);
      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }]
      };
    } catch (err) {
      const msg = err instanceof CozntApiError ? `${err.message} (status ${err.status}${err.details ? `, details: ${JSON.stringify(err.details)}` : ""})` : err instanceof Error ? err.message : "unknown error";
      mcpLog(`dispatch: ERROR verb=${req.params.name} err=${msg}`);
      return {
        content: [{ type: "text", text: msg }],
        isError: true
      };
    }
  });
  server.setRequestHandler(ListResourcesRequestSchema, async () => ({
    resources: RESOURCES.map((r) => ({
      uri: r.uri,
      name: r.name,
      description: r.description,
      mimeType: r.mimeType
    }))
  }));
  server.setRequestHandler(ReadResourceRequestSchema, async (req) => {
    const found = RESOURCES.find((r) => r.uri === req.params.uri);
    if (!found) {
      throw new Error(`Unknown resource: ${req.params.uri}`);
    }
    return found.read(client);
  });
  return server;
}

// src/mcp/bin.ts
async function main() {
  const arg = process.argv[2];
  if (arg === "--version" || arg === "-v") {
    process.stdout.write(`${MCP_VERSION}
`);
    return;
  }
  if (arg === "--help" || arg === "-h") {
    process.stdout.write(
      `coznt-mcp ${MCP_VERSION}

Usage: coznt-mcp              Start the MCP server over stdio.
       coznt-mcp --version    Print version and exit.

Required env: COZNT_API_KEY. Optional: COZNT_URL (default http://localhost:3029).
`
    );
    return;
  }
  const server = createCozntMcpServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
main().catch((err) => {
  const msg = err instanceof Error ? err.message : String(err);
  process.stderr.write(`coznt-mcp failed to start: ${msg}
`);
  process.exit(1);
});
//# sourceMappingURL=bin.js.map
//# sourceMappingURL=bin.js.map